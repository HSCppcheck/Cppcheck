int main()
{
	int *p1;
	int *p2 = p1;
	*p1 = 0;
	*p2 = 0;
}